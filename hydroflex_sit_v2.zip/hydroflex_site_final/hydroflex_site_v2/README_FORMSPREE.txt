
HYDROFLEX v2 - Instrucciones Formspree y despliegue
==================================================

Archivos incluidos:
- index.html
- hydroflex.html
- tecnologia.html
- sustentabilidad.html
- contacto.html
- style.css
- script.js
- carpeta img/ con logos y SVGs
- README_FORMSPREE.txt (este)

FORMSPREE (para que el contacto envíe a santi2008guerra@gmail.com):
1) Ir a https://formspree.io/ y crear cuenta (o iniciar sesión).
2) Crear un nuevo "Form" y seguir pasos. Obtendrás un endpoint como:
   https://formspree.io/f/FORM_ID
3) Reemplazar en contacto.html la acción: action="https://formspree.io/f/{FORM_ID}"
4) Verificar el correo en Formspree (te mandan un email). Tras verificar, las sumisiones llegarán a santi2008guerra@gmail.com.

DESPLIEGUE:
- Subir la carpeta al hosting (Netlify, Vercel, GitHub Pages o FTP).
- Si usas GitHub Pages, crear repo y subir la carpeta; index.html será la portada.

Si querés que agregue:
- reemplazo del FORM_ID por el real (me pasás el ID y lo cambio),
- imágenes reales (me las subís),
- texto personalizado o políticas,
dímelo y lo hago.
